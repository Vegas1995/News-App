//
//  NewsTableViewController.swift
//  newsApp
//
//  Created by Валерий Мустафин on 29.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
//output
protocol ArticlesViewProtocol: class {
    func updateCell()
    func errorFetch(error: Error)
    
    func enabledView(complete: Bool)
}
//input
protocol ArticlesViewModelProtocol: class {
    init(view: ArticlesViewProtocol, networkService: NetworkServiceProtocol, model: [Article], inputModel: Source)
    //init tableView
    func getArticlesItemViewModel(at indexPath: IndexPath) -> ArticleItemViewModelProtocol
    func numberOfRowsInSection() -> Int
    func heightOfCells() -> Float
    func getTitleSource() -> String
    func configNavigationItem() -> Bool
    // transport data
    func selectRow(at indexPath: IndexPath) -> Article
    func pushSourceTitle() -> Source
    //Work With SerchBar
    func getTextFromUser(text: String?)
    func addSimpleRequestArticle()
    func addRequestAfterTapSearch()
}

final class ArticlesViewModel: ArticlesViewModelProtocol {
    
    weak var view: ArticlesViewProtocol?
    let networkService: NetworkServiceProtocol
    let modelSource: Source
    var modelArticle: [Article]
    private var page = 1
    private var stopUpdate = false
    private var numbersResult = 0
    private var maxNumbersResult = 100
    private var textSearch = "" {
        didSet {
            if textSearch == "" {
                configModule(value: .loadArticles)
            } else {
                configModule(value: .searchArticles)
            }
        }
    }
    
    //MARK: Init
    init(view: ArticlesViewProtocol, networkService: NetworkServiceProtocol, model: [Article], inputModel: Source) {
        self.modelArticle = model
        self.view = view
        self.networkService = networkService
        self.modelSource = inputModel
    }
    
    //MARK: Protocol function
    func configNavigationItem() -> Bool {
        if modelSource.name?.count ?? 0 < 23 {
            return true
        } else {
            return false
        }
    }
    
    func heightOfCells() -> Float {
        return 250
    }
    
    func getTitleSource() -> String {
        return modelSource.name ?? "Articles"
    }
    
    func numberOfRowsInSection() -> Int {
        return modelArticle.count
    }
    
    func selectRow(at indexPath: IndexPath) -> Article {
        let article = modelArticle[indexPath.row]
        return article
    }
    
    func pushSourceTitle() -> Source {
        return modelSource
    }
    
    func getTextFromUser(text: String?) {
        guard let textValue = text else {
            configModule(value: .loadArticles)
            return
        }
        textSearch = String.getCurrentSearchText(textValue)()
    }
    
    func addRequestAfterTapSearch() {
        configModule(value: .searchArticles)
    }
    
    func addSimpleRequestArticle() {
        configModule(value: .loadArticles)
    }
    
    func getArticlesItemViewModel(at indexPath: IndexPath) -> ArticleItemViewModelProtocol {
        let article = modelArticle[indexPath.row]
        getSome(indexPath: indexPath)
        return ArticleItemViewModel(title: article.title, author: article.author, image: article.urlToImage)
    }
}

//MARK: Private function
extension ArticlesViewModel {
    private func getSome(indexPath: IndexPath) {
        guard modelArticle.count < maxNumbersResult else { return }
        guard modelArticle.count < numbersResult else { return }
        guard modelArticle[indexPath.row].title == modelArticle.last?.title ,stopUpdate == false  else { return }
        configModule(value: .loadMoreArticles)
    }
    
    private func configModule(value: ConfigurationLoadData) {
        switch value {
        case .searchArticles:
            fetchSearchedArticle(searchText: textSearch)
        case .loadMoreArticles:
            fetchMoreArticle(page: page)
        case .loadArticles:
            fetchArticle()
        }
    }
    
    private func fetchSearchedArticle(searchText: String?) {
        self.view?.enabledView(complete: false)
        guard let value = searchText, let id = modelSource.id else { return }
        networkService.fetchSourceSearchEveryThing(source: id, searchText: value) { [weak self] (response, error, totalResult) in
            if error != nil {
                self?.view?.errorFetch(error: error!)
                self?.stopUpdate = true
            }
            guard let response = response else { return }
            guard let responseValue = response.totalResults else { return }
            self?.numbersResult = responseValue
            self?.modelArticle = response.articles
            self?.updateViewAfrterRequest()
        }
    }
    
    private func fetchMoreArticle(page: Int) {
        self.view?.enabledView(complete: false)
        guard let id = modelSource.id else { return }
        self.page += 1
        networkService.fetchSourceEveryThing(source: id, page: page) { [weak self] (response, error, totalResult) in
            if error != nil {
                self?.view?.errorFetch(error: error!)
                self?.stopUpdate = true
            }
            guard let response = response else { return }
            self?.modelArticle.append(contentsOf: response.articles)
            self?.updateViewAfrterRequest()
        }
    }
    
    private func fetchArticle() {
        self.page += 1
        self.view?.enabledView(complete: false)
        guard let id = modelSource.id else { return }
        networkService.fetchSourceEveryThing(source: (id), page: 1) { [weak self] (response, error, totalresult)  in
            if error != nil {
                self?.view?.errorFetch(error: error!)
                self?.stopUpdate = true
            }
            guard let response = response else { return }
            guard let responseValue = response.totalResults else { return }
            self?.numbersResult = responseValue
            self?.modelArticle = response.articles
            self?.updateViewAfrterRequest()
        }
    }
    
    private func updateViewAfrterRequest() {
        self.view?.updateCell()
        self.view?.enabledView(complete: true)
    }
}

//MARK: Enum: ConfigurationLoadData
extension ArticlesViewModel {
    enum ConfigurationLoadData {
        case searchArticles
        case loadMoreArticles
        case loadArticles
    }
}
