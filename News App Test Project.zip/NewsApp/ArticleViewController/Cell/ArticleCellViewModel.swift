//
//  ArticleCellModel.swift
//  newsApp
//
//  Created by Валерий Мустафин on 08.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation


protocol ArticleItemViewModelProtocol {
    var associatedClass: CellArticleProtocol.Type { get set }
}

struct ArticleItemViewModel: ArticleItemViewModelProtocol {
    var associatedClass: CellArticleProtocol.Type = ArticleCell.self
    let title: String?
    let author: String?
    let image: URL?
    
//    func returnData() -> (URL?) {
//        var dataImage: Data?
//        guard let urlValue = image else { return nil }
//        do {
//            if let data = try? Data(contentsOf: urlValue)   {
//                dataImage = data
//                   }
//               } catch { return nil }
//        return dataImage
//    }
    
}
