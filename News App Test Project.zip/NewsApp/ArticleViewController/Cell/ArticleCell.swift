//
//  ArticleCell.swift
//  newsApp
//
//  Created by Валерий Мустафин on 08.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit
import SDWebImage

protocol CellArticleProtocol: UITableViewCell {
    static var identifier: String { get }
    func configure(with viewModel: ArticleItemViewModelProtocol)
    func firstSelectRowAnimation(completion: @escaping(Bool) -> ())
}

//MARK: Setup UI
class ArticleCell: UITableViewCell, CellArticleProtocol {
    static var identifier = "ArticleCell"
    
    var titleFromModel = UILabel(text: "Error", numberOfLines: 0, textAlignment: .left, fontSize: 16, colorShadow: nil, textColor: .mainColorBlack)
    var authorFromModel = UILabel(text: "Error", numberOfLines: 0, textAlignment: .right, fontSize: 14, colorShadow: nil, textColor: .mainColorBlack)
    let imageIcon = UIImageView(with: #imageLiteral(resourceName: "planet"), contentMode: .scaleAspectFill, cornerRadius: 35)
    let containerViewFront = UIView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = .clear
        addElementFront()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private  func addElementFront() {
        self.addSubview(containerViewFront)
        containerViewFront.addSubview(imageIcon)
        containerViewFront.addSubview(titleFromModel)
        containerViewFront.addSubview(authorFromModel)
        configureContainer()
        makeConstraintsToFront()
    }
    
    private func configureContainer() {
        //почему то применяется ко всему кроме самой въюхе>>> containerView.layer.masksToBounds = true/false
        containerViewFront.layer.borderColor = UIColor.mainColorGray.cgColor
        containerViewFront.layer.cornerRadius = 35
        containerViewFront.layer.borderWidth = 1
        containerViewFront.layer.masksToBounds = true
        containerViewFront.layer.shadowColor = UIColor.mainColorGray.cgColor
        containerViewFront.layer.shadowOffset = CGSize(width: 2, height: 2)
        containerViewFront.layer.rasterizationScale = UIScreen.main.scale
        containerViewFront.layer.shadowRadius = 6
        containerViewFront.layer.shadowOpacity = 1.0
    }
    
    //MARK: ConfigureCells
    func configure(with viewModel: ArticleItemViewModelProtocol) {
        guard let viewModel = viewModel as? ArticleItemViewModel else {
            titleFromModel.text = ""
            authorFromModel.text = ""
            imageIcon.image = #imageLiteral(resourceName: "planet")
            return
        }
        titleFromModel.text = viewModel.title ?? ""
        authorFromModel.text = viewModel.author ?? ""
        guard let dataValue = viewModel.image else { return }
        imageIcon.sd_setImage(with: dataValue)
        guard imageIcon.image == nil else { return }
        imageIcon.image = #imageLiteral(resourceName: "planet")
    }
    
    //MARK: Animation
    func firstSelectRowAnimation(completion: @escaping(Bool) -> ()) {
        UIView.animate(withDuration: 0.6, animations: {
            self.containerViewFront.transform = CGAffineTransform(scaleX: 1.1, y: 1.5)
            self.containerViewFront.backgroundColor = .mainColorGray
        }) { [weak self] (finishedFirst) in
            self?.seconsdSelectRowAnimation(command: finishedFirst) { (finishedSecond) in
                self?.thirdSelectRowAnimation(command: finishedSecond) { (finishedyThird) in
                    completion(finishedyThird)
                }
            }
        }
    }
    
    private func seconsdSelectRowAnimation(command: Bool, completion: @escaping(Bool) -> ()) {
        let transitionOptions: UIView.AnimationOptions = [.transitionFlipFromLeft, .showHideTransitionViews]
        UIView.transition(from: imageIcon, to: imageIcon, duration: 0.5, options: transitionOptions) { (result) in
            completion(result)
        }
    }
    
    private func thirdSelectRowAnimation(command: Bool, completion: @escaping(Bool) -> ()) {
        let transitionOptions: UIView.AnimationOptions = [.curveLinear, .showHideTransitionViews]
        UIView.animate(withDuration: 0.2, delay: 0.3, options: transitionOptions, animations: {
            self.containerViewFront.transform = CGAffineTransform(translationX: self.center.x, y: 0)
            
        }) { (finishedyThird) in
            completion(finishedyThird)
            self.reBuildElement()
        }
    }
    
    private func reBuildElement() {
        UIView.animate(withDuration: 0.2, delay: 1, options: [], animations: {
        }) { [weak self] (some) in
            self?.containerViewFront.transform = .identity
            self?.containerViewFront.backgroundColor = .clear
        }
    }
}
