//
//  NetworkService.swift
//  newsApp
//
//  Created by Валерий Мустафин on 24.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
import Alamofire

protocol NetworkServiceProtocol {
    func fetchSource(completion: @escaping(SourcesResponse? , Error?) -> ())
    func fetchSourceSearchEveryThing(source: String,
                                     searchText: String,
                                     completion: @escaping(NewsResponse? , Error?, Int?) -> ())
    func fetchSourceEveryThing(source: String,
                               page: Int,
                               completion: @escaping(NewsResponse? , Error?, Int?) -> ())
}

class NetworkService: NetworkServiceProtocol {
    let source = "https://newsapi.org/v2/sources?"
    let evething = "https://newsapi.org/v2/everything?sources="
    let fromDate = "from=2020-10-01"
    let sort = "sortBy=publishedAt"
    let pages = "page="
    let pagesize = "pageSize=100"
    let apiKey = "apiKey=66058fed792b455384ed16b02f7c9a46"
    let parameters = ["language":"en"]
    
    func fetchSource(completion: @escaping(SourcesResponse?, Error?) -> ()) {
        let url = "\(source)&\(apiKey)"
        AF.request(url as URLConvertible, method: .get,parameters: parameters).responseDecodable(of: SourcesResponse.self) { (response) in
            switch response.result {
            case .success(let data):
                completion(data, nil)
            case .failure(let error):
                completion(nil, error)
            }
        }
    }
    
    func fetchSourceEveryThing(source: String,
                               page: Int,
                               completion: @escaping (NewsResponse?, Error?, Int?) -> ()) {
        let url = "\(evething)\(source)&\(fromDate)&\(sort)&\(apiKey)&\(pages)\(page)"
        print(page)
        AF.request(url as URLConvertible, method: .get).responseDecodable(of: NewsResponse.self) { (response) in
            switch response.result {
            case .success(let data):
                completion(data, nil, data.totalResults)
            case .failure(let error):
                completion(nil, error, nil)
            }
        }
    }
    
    func fetchSourceSearchEveryThing(source: String,
                                     searchText: String,
                                     completion: @escaping (NewsResponse?, Error?, Int?) -> ()) {
        let url = "\(evething)\(source)&\(fromDate)&\(searchText)&\(sort)&\(apiKey)&\(pagesize)"
        AF.request(url as URLConvertible, method: .get).responseDecodable(of: NewsResponse.self) { (response) in
            switch response.result {
            case .success(let data):
                completion(data, nil, data.totalResults)
            case .failure(let error):
                completion(nil, error, nil)
            }
        }
    }
}
