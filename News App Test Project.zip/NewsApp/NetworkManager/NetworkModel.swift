//
//  NetworkModel.swift
//  newsApp
//
//  Created by Валерий Мустафин on 24.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation

struct NewsResponse: Decodable {
    var status: String
    var totalResults: Int?
    var message: String?
    var articles: [Article]
}

struct SourcesResponse: Decodable {
    var status: String
    var message: String?
    var sources: [Source]
}
