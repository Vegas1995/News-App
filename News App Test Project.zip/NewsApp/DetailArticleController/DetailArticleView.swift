//
//  DetailArticleView.swift
//  newsApp
//
//  Created by Валерий Мустафин on 09.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit
import SDWebImage

//MARK: Setup UI
class DetailArticleView: UIViewController {
    var viewModel: DetailArticleViewModelProtocol!
    let titleLabel = UILabel(text: "", numberOfLines: 0, textAlignment: .right, fontSize: 20, colorShadow: nil, textColor: .mainColorBlack)
    let urlLabel = UILabel(text: "", numberOfLines: 0, textAlignment: .right, fontSize: 12, colorShadow: nil, textColor: .mainColorBlack)
    let contentLabel = UILabel(text: "", numberOfLines: 0, textAlignment: .left, fontSize: 16, colorShadow: nil, textColor: .mainColorBlack)
    let timePublishLabel = UILabel(text: "", numberOfLines: 0, textAlignment: .right, fontSize: 12, colorShadow: nil, textColor: .mainColorBlack)
    let articleImage = UIImageView(with: #imageLiteral(resourceName: "planet"), contentMode: .scaleAspectFill, cornerRadius: 0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.createGradient(colorFirst: .mainColorPinK,
                                  colorLast: .mainColorViolet,
                                  startPoint: CGPoint(x: 0, y: 0),
                                  endPoint: CGPoint(x: 0, y: 1),
                                  useAnimation: false)
        addElement()
        prepareForAnimation()
        makeConstraints()
        title = viewModel.getTitleArticle()
        addAnimation()
    }
    
    private func addElement() {
        view.addSubview(articleImage)
        view.addSubview(titleLabel)
        view.addSubview(urlLabel)
        view.addSubview(contentLabel)
        view.addSubview(timePublishLabel)
    }
    
    private func prepareForAnimation() {
        let const: CGFloat = CGFloat(viewModel.getIndent())
        articleImage.alpha = 0
        articleImage.transform = CGAffineTransform(scaleX: 0, y: 0)
        titleLabel.transform = CGAffineTransform(translationX: const, y: 0)
        urlLabel.transform = CGAffineTransform(translationX: -const, y: 0)
        contentLabel.transform = CGAffineTransform(translationX: const, y: 0)
        timePublishLabel.transform = CGAffineTransform(translationX: -const, y: 0)
    }
}

//MARK: OUTPUT from viewModel
extension DetailArticleView: DetailArticleViewProtocol {
     func updateData() {
        titleLabel.text = viewModel.getDataTitle()
        urlLabel.text = viewModel.getDataUrl()
        contentLabel.text = viewModel.getDataContent()
        timePublishLabel.text = viewModel.getDataTime()
        guard let dataValue = viewModel.getDataImage() else { return }
        articleImage.sd_setImage(with: dataValue)
    }
}

//MARK: Animation
extension DetailArticleView {
    private func addAnimation() {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
            self.articleImage.transform = .identity
            self.articleImage.alpha = 1
        }) { (finished) in
            self.addFinalAnimation()
        }
    }
    
    private func addFinalAnimation() {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
            self.titleLabel.transform = .identity
            self.urlLabel.transform = .identity
            self.contentLabel.transform = .identity
            self.timePublishLabel.transform = .identity
        })
    }
}
