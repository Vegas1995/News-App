//
//  ViewData.swift
//  newsApp
//
//  Created by Валерий Мустафин on 25.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation

struct Source: Decodable {
    var id: String?
    var name: String?
    var description: String?
    var url: String?
    var category: String?
    var country: String?
    var language: String?
}
