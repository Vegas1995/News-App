//
//  NewsCellModel.swift
//  newsApp
//
//  Created by Валерий Мустафин on 07.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation

protocol NewsItemViewModelProtocol {
    var associatedClass: CellNewsProtocol.Type { get set }
}

struct NewsItemViewModel: NewsItemViewModelProtocol {
    var associatedClass: CellNewsProtocol.Type = NewsCell.self
    let title: String?
    let category: String?
}




