//
//  myCell.swift
//  newsApp
//
//  Created by Валерий Мустафин on 24.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
import UIKit
import SnapKit

protocol CellNewsProtocol: UICollectionViewCell {
    static var identity: String { get }
    func configure(with viewModel: NewsItemViewModelProtocol)
    func flipCardAnimation(completion: @escaping((Bool) -> ()))
}

//MARK: Setup UI
class NewsCell: UICollectionViewCell, CellNewsProtocol {
    
    static var identity = "NewsCell"
    var titleCell = UILabel(text: "NEWS", numberOfLines: 0, textAlignment: NSTextAlignment.center, fontSize: 24, colorShadow: .mainColorWhite, textColor: .mainColorWhite)
    var categoryLabel = UILabel(text: "", numberOfLines: 0, textAlignment: NSTextAlignment.center, fontSize: 18, colorShadow: .mainColorWhite, textColor: .mainColorWhite)
    var previewImage = UIImageView(with: #imageLiteral(resourceName: "planet"), contentMode: .scaleAspectFit, cornerRadius: 35)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureShadowLayer()
        configureGradient()
        addElements()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureShadowLayer () {
        self.layer.cornerRadius = 35
        self.layer.borderWidth = 0.0
        self.layer.shadowColor = UIColor.mainColorBlack.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowRadius = 10
        self.layer.shadowOpacity = 1
        self.layer.masksToBounds = true //<-
    }
    
    private func configureGradient() {
        self.createGradient(colorFirst: .random, colorLast: .random, startPoint: CGPoint(x: 0, y: 0), endPoint: CGPoint(x: 1, y: 1), useAnimation: true)
    }
    
    private func addElements() {
        self.addSubview(previewImage)
        previewImage.addSubview(titleCell)
        previewImage.addSubview(categoryLabel)
        addMainConstraints()
    }
    
    func configure(with viewModel: NewsItemViewModelProtocol) {
        guard let viewModel = viewModel as? NewsItemViewModel else {
            titleCell.text = ""
            categoryLabel.text = ""
            return
        }
        titleCell.text = viewModel.title
        categoryLabel.text = viewModel.category
    }
    
    //MARK: Animations
    func flipCardAnimation(completion: @escaping((Bool) -> ())) {
        let transitionOptions: UIView.AnimationOptions = [.transitionFlipFromLeft, .showHideTransitionViews]
        UIView.transition(from: previewImage, to: previewImage, duration: 0.5, options: transitionOptions) { [weak self] (result) in
            self?.rotateViewOnStandartVision(result: result) { (endAnimation) in
                completion(endAnimation)
            }
        }
    }
    
    private func rotateViewOnStandartVision(result: Bool, completion: @escaping((Bool) -> ())) {
        let transitionOptions: UIView.AnimationOptions = [.transitionFlipFromLeft, .showHideTransitionViews]
        UIView.transition(from: previewImage, to: previewImage, duration: 0.5, options: transitionOptions) { (result) in
            completion(true)
        }
    }
}
