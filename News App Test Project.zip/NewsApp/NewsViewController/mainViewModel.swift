//
//  mainViewModel.swift
//  newsApp
//
//  Created by Валерий Мустафин on 25.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
import CoreGraphics

//output
protocol NewsViewProtocol: class {
    func updateCell()
    func errorFetch(error: Error)
}

//input
protocol NewsViewModelProtocol: class {
    init(view: NewsViewProtocol,
         networkService: NetworkServiceProtocol,
         modelSources: [Source])
    //init collectionView
    var spacing: CGFloat { get }
    func numberSection() -> Int
    func itemInRow() -> CGFloat
    func numberOfItemInSection() -> Int
    func minimumInteritemSpacingForSectionAt() -> CGFloat
    func sizeForItemAt(width: CGSize) -> CGSize
    // transport data
    func getNewsItemViewModel(at indexPath: IndexPath) -> NewsItemViewModelProtocol
    func fetchSource()
    // transort data other view
    func selectRow(at indexPath: IndexPath) -> Source
}

final class NewsViewModel: NewsViewModelProtocol {
    
    weak var view: NewsViewProtocol?
    let networkService: NetworkServiceProtocol
    var modelSources: [Source]
    
    //MARK: Init
    init(view: NewsViewProtocol, networkService: NetworkServiceProtocol, modelSources: [Source]) {
        self.view = view
        self.networkService = networkService
        self.modelSources = modelSources
        fetchSource()
    }
    
    var spacing: CGFloat = 20
    func numberSection() -> Int {
        return 1
    }
    
    func itemInRow() -> CGFloat {
        return 2
    }
    
    func numberOfItemInSection() -> Int {
        return modelSources.count
    }
    
    func minimumInteritemSpacingForSectionAt() -> CGFloat {
        return spacing
    }
    
    func sizeForItemAt(width: CGSize) -> CGSize {
        let paddingWidth = spacing * (itemInRow() + 1)
        let availableWidth = width.width - paddingWidth
        let widthPerItem = availableWidth / itemInRow()
        return CGSize(width: widthPerItem, height: widthPerItem)
    }
    
    func selectRow(at indexPath: IndexPath) -> Source {
        let source = modelSources[indexPath.row]
        return source
    }
    
    func getNewsItemViewModel(at indexPath: IndexPath) -> NewsItemViewModelProtocol {
        let source = modelSources[indexPath.row]
        return NewsItemViewModel(title: source.name ?? "", category: source.category ?? "")
    }
    
    //MARK: Network Service
    func fetchSource() {
        networkService.fetchSource { [weak self] (response, error) in
            if error != nil {
                self?.view?.errorFetch(error: error!)
            }
            guard let response = response else { return }
            self?.modelSources = response.sources
             self?.view?.updateCell()
        }
    }
}

