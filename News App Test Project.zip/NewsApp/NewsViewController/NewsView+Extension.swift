//
//  NewsView+Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 29.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
import UIKit


extension NewsView {
    
    //MARK: CollectionView Setup
    func makeCollectionView() -> UICollectionView {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let collectionview = UICollectionView(frame: view.frame, collectionViewLayout: layout)
        collectionview.dataSource = self
        collectionview.delegate = self
        collectionview.showsVerticalScrollIndicator = false
        collectionview.backgroundColor = .clear
        collectionview.register(NewsCell.self, forCellWithReuseIdentifier: "NewsCell")
        view.addSubview(collectionview)
        return collectionview
    }
}

extension NewsView: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    // MARK: UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return viewModel.sizeForItemAt(width: view.frame.size)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return collectionView.configureCellSpacing(viewModel: viewModel)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return viewModel.minimumInteritemSpacingForSectionAt()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return viewModel.minimumInteritemSpacingForSectionAt()
    }
    
    // MARK: UICollectionViewDataSource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return viewModel.numberSection()
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        return viewModel.numberOfItemInSection()
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard  let cell = collectionView.getCellProtocol(for: viewModel.getNewsItemViewModel(at: indexPath), indexPath: indexPath) else { fatalError("Не становись программистом") }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        didSelectItemAt indexPath: IndexPath) {
        collectionView.routerColletionView(for: indexPath) { (result) in
            self.navigationController?.pushViewController(ModuleBuilder.createModuleArticle(inputModel: self.viewModel.selectRow(at: indexPath)), animated: true)
        }
    }
}

//MARK: Extension: UICollectionView
extension UICollectionView {
    func getCellProtocol(for viewModel: NewsItemViewModelProtocol, indexPath: IndexPath) -> CellNewsProtocol? {
        guard let cell = dequeueReusableCell(withReuseIdentifier: viewModel.associatedClass.identity, for: indexPath) as? CellNewsProtocol else { fatalError("Не становись программистом") }
        cell.configure(with: viewModel)
        return cell
    }
    
    func routerColletionView(for indexPath: IndexPath, completion: @escaping((Bool) -> ())) {
        let cell = self.cellForItem(at: indexPath) as? CellNewsProtocol
        cell?.flipCardAnimation(completion: { (result) in
            completion(result)
        })
    }
    
    func configureCellSpacing(viewModel: NewsViewModelProtocol) -> UIEdgeInsets {
        let value = viewModel.spacing
        let sectionInserts = UIEdgeInsets(top: value,
                                          left: value,
                                          bottom: value,
                                          right: value)
        return sectionInserts
    }
}

