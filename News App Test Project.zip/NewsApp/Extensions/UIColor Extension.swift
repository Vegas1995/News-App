//
//  UIColor Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 06.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

extension UIColor {
    static var mainColorPinK: UIColor {
        return  #colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)
    }
    
    static var mainColorViolet: UIColor {
        return  #colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1)
    }
    
    static var mainColorGray: UIColor {
        return #colorLiteral(red: 0.7528558373, green: 0.7529891133, blue: 0.7528572679, alpha: 1)
    }
    
    static var mainColorBlack: UIColor {
        return #colorLiteral(red: 0.04272372276, green: 0.03926201165, blue: 0.09517853707, alpha: 1)
    }
    
    static var mainColorWhite: UIColor {
        return #colorLiteral(red: 0.9578339041, green: 0.9606699486, blue: 0.963479238, alpha: 1)
    }
}

extension CGFloat {
    static var random: CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}
extension UIColor {
    static var random: UIColor {
        return UIColor(red: .random, green: .random, blue: .random, alpha: 1.0)
    }
}
