//
//  UILabel Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 08.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

extension UILabel {
    func UILableTextShadow(color: UIColor){
        self.textColor = color
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.mainColorBlack.cgColor
        self.layer.shadowOffset = CGSize(width: 1, height: 1)
        self.layer.rasterizationScale = UIScreen.main.scale
        self.layer.shadowRadius = 6.0
        self.layer.shadowOpacity = 1.0
    }
    
    convenience init(text: String, numberOfLines: Int, textAlignment: NSTextAlignment, fontSize: CGFloat, colorShadow: UIColor?, textColor: UIColor) {
        self.init()
        self.text = text
        self.textColor = textColor
        self.textAlignment = textAlignment
        self.font = .systemFont(ofSize: fontSize)
        self.numberOfLines = numberOfLines
        
        guard let newValue = colorShadow else { return }
        self.UILableTextShadow(color: newValue)
       
    }
}
