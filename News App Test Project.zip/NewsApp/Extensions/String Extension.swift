//
//  String Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 09.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation

extension String {
    
    func getCurrentSearchText() -> String {
        guard self != "" else { return self }
        let badCharacters: Set<Character> = [" ", ">", "<", "+", ".", ",", "/", "\'", "="]
        var basicText = self
        basicText.removeAll(where: { badCharacters.contains($0) })
        let currentText = "q=\(basicText)"
        return currentText
    }
    
    mutating func getCurrentDate() -> String {
        guard self != "" else { return self }
        var basicText = self
        let badCharacters: Set<Character> = ["-", "T", "Z", ":"]
               basicText.removeAll(where: { badCharacters.contains($0) })
        basicText.removeLast()
        basicText.removeLast()
        
        //text without crash sympols
        let cleanText = basicText
        var currentText = ""
        var arr = Array(cleanText)
        
        //change time with year
        arr.swapAt(0, 8)
        arr.swapAt(1, 9)
        arr.swapAt(2, 10)
        arr.swapAt(3, 11)
        
        // change month with day
        arr.swapAt(4, 6)
        arr.swapAt(5, 7)
        
        // add helper sympol
        arr.insert(":", at: 2)
        arr.insert(" ", at: 5)
        arr.insert(".", at: 8)
        arr.insert(".", at: 11)
        
        //save
        for char in arr {
            currentText.append(char)
        }
        return currentText
    }
}
