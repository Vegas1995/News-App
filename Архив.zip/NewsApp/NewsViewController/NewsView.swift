//
//  ViewController.swift
//  newsApp
//
//  Created by Валерий Мустафин on 24.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit
import SnapKit
import Alamofire

//MARK: Setup UI
class NewsView: UIViewController {
    var viewModel: NewsViewModelProtocol!
    lazy var collectionView = makeCollectionView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        configureNavBar()
    }
    
    private func configureView() {
        title = "News"
        view.createGradient(colorFirst: .mainColorPinK,
                            colorLast: .mainColorViolet,
                            startPoint: CGPoint(x: 0, y: 0),
                            endPoint: CGPoint(x: 0, y: 1),
                            useAnimation: false)
    }
    
    func configureNavBar() {
        navigationController?.navigationBar.barStyle = .default
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.barTintColor = .mainColorPinK
    }
}

//MARK: OUTPUT from viewModel
extension NewsView: NewsViewProtocol  {
    
    func errorFetch(error: Error) {
        let alertController = UIAlertController(title: "Error", message: "\(error.localizedDescription)", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .cancel)
        alertController.addAction(okAction)
        DispatchQueue.main.async {
            self.present(alertController, animated: true)
        }
    }
    
    func updateCell() {
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
}

