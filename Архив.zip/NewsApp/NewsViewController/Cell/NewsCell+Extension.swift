//
//  NewsCell+Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 12.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit


//MARK: Constraints
extension NewsCell {
    func addMainConstraints() {
        previewImage.snp.makeConstraints { (make) in
            make.right.bottom.left.top.equalToSuperview()
        }
        
        titleCell.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.left.equalToSuperview().offset(8)
            make.right.equalToSuperview().offset(-8)
            make.centerY.equalToSuperview().offset(-12)
        }
        
        categoryLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.left.equalToSuperview().offset(8)
            make.right.equalToSuperview().offset(-8)
            make.top.equalTo(titleCell.snp.bottom).offset(3)
        }
    }
}
