//
//  ArticleView+Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 12.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

//MARK: UISearchControllerDelegate
extension ArticlesView: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.getTextFromUser(text: searchText)
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        viewModel.addSimpleRequestArticle()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        viewModel.addRequestAfterTapSearch()
    }
}

//MARK: UITableViewDataSource, UITableViewDelegate
extension ArticlesView: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRowsInSection()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return tableView.getCellProtocol(for: viewModel.getArticlesItemViewModel(at: indexPath))
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.routerTableView(for: indexPath) { (start) in
            self.navigationController?.pushViewController(ModuleBuilder.createModuleDetailArticle(inputModel: self.viewModel.selectRow(at: indexPath), inputModelSource: self.viewModel.pushSourceTitle()), animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        CGFloat(viewModel.heightOfCells())
    }
}

extension UITableView {
    func routerTableView(for indexPath: IndexPath, completion: @escaping((Bool) -> ())) {
           let cell = cellForRow(at: indexPath) as? CellArticleProtocol
        cell?.firstSelectRowAnimation(completion: { (finishedAnimation) in
            completion(finishedAnimation)
          //  cell?.reBuildElement()
        })
       }
    
    func getCellProtocol(for vm: ArticleItemViewModelProtocol) -> CellArticleProtocol {
        guard let cell = dequeueReusableCell(withIdentifier: vm.associatedClass.identifier) as? CellArticleProtocol else { fatalError("Не становись программистом") }
        cell.selectionStyle = .none
        cell.configure(with: vm)
        return cell
    }
}
