//
//  ArticleCell+Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 12.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
//MARK: Constraints
extension ArticleCell {
    func makeConstraintsToFront() {
        containerViewFront.snp.makeConstraints { (makes) in
            makes.leftMargin.topMargin.rightMargin.bottomMargin.equalToSuperview()
        }
        
        imageIcon.snp.makeConstraints { (makes) in
            makes.leftMargin.topMargin.rightMargin.equalToSuperview()
            makes.height.equalTo(150)
        }
        
        titleFromModel.snp.makeConstraints { (makes) in
            makes.left.equalToSuperview().offset(16)
            makes.top.equalTo(imageIcon.snp.bottom).offset(12)
            makes.right.equalToSuperview().offset(-16)
        }
        
        authorFromModel.snp.makeConstraints { (makes) in
            makes.left.equalToSuperview().offset(16)
            makes.top.equalTo(titleFromModel.snp.bottom).offset(12)
            makes.right.equalToSuperview().offset(-16)
        }
    }
}
