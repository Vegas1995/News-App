//
//  model.swift
//  newsApp
//
//  Created by Валерий Мустафин on 29.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation

struct Article: Decodable {
    
    var title: String?
    var description: String?
    var author: String?
    var urlToImage: URL?
    var url: URL?
    var publishedAt: String?
    var content: String?
}
