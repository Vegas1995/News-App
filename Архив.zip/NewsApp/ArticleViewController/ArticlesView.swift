//
//  ViewController.swift
//  newsApp
//
//  Created by Валерий Мустафин on 29.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit
import SnapKit

//MARK: Setup UI
class ArticlesView: UIViewController {
    
    var viewModel: ArticlesViewModelProtocol!
    private lazy var tableView = makeTableView()
    private let downloadView = UIActivityIndicatorView()
    private var flagForIndicator = true
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        view.addSubview(downloadView)
        animationIndecator()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.addSimpleRequestArticle()
        configureView()
        configureSearchBar()
        
    }
    
    private func animationIndecator() {
        if flagForIndicator {
            downloadView.center = view.center
            downloadView.startAnimating()
            flagForIndicator = false
        }
    }
    
    private func configureView() {
        title = viewModel.getTitleSource()
        view.createGradient(colorFirst: .mainColorPinK, colorLast: .mainColorViolet, startPoint: CGPoint(x: 0, y: 0), endPoint: CGPoint(x: 0, y: 1), useAnimation: false)
    }
    
    private func configureSearchBar() {
        if viewModel.configNavigationItem() {
            navigationItem.largeTitleDisplayMode = .automatic
        } else {
            navigationItem.largeTitleDisplayMode = .never
        }
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.layoutIfNeeded()
        navigationController?.navigationBar.tintColor = .mainColorWhite
        let searchController = UISearchController(searchResultsController: nil)
        searchController.setupSearchControllerDesign()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    
    //MARK: SetupTableView
    private func makeTableView() -> UITableView {
        let tableView = UITableView()
        tableView.register(ArticleCell.self, forCellReuseIdentifier: "ArticleCell")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .mainColorPinK
        tableView.separatorStyle = .none
        view.addSubview(tableView)
        tableView.backgroundColor = .clear
        tableView.snp.makeConstraints { (make) in
            make.topMargin.equalToSuperview().offset(25)
            make.rightMargin.leftMargin.bottom.equalToSuperview()
        }
        return tableView
    }
    
    func makeDowloadView() -> UIView {
        let downloadView = UIView()
        view.addSubview(downloadView)
        downloadView.snp.makeConstraints { (makes) in
            makes.leftMargin.topMargin.rightMargin.bottomMargin.equalToSuperview()
        }
        downloadView.createGradient(colorFirst: .mainColorWhite,
                                    colorLast: .mainColorViolet,
                                    startPoint: CGPoint(x: 0, y: 0),
                                    endPoint: CGPoint(x: 0, y: 1),
                                    useAnimation: false)
        return downloadView
    }
}

//MARK: OUTPUT from viewModel
extension ArticlesView: ArticlesViewProtocol {
    func errorFetch(error: Error) {
        let alertController = UIAlertController(title: "Error", message: "\(error.localizedDescription)", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .cancel)
        alertController.addAction(okAction)
        DispatchQueue.main.async {
            self.present(alertController, animated: true)
        }
    }
    
    func updateCell() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func enabledView(complete: Bool) {
        view.isUserInteractionEnabled = complete
        DispatchQueue.main.async {
            self.downloadView.isHidden = complete
            switch complete {
            case false:
                self.downloadView.startAnimating()
            case true:
                self.downloadView.stopAnimating()
            }
        }
    }
}


