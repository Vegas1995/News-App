//
//  UISearchController.swift
//  newsApp
//
//  Created by Валерий Мустафин on 12.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

extension UISearchController {
    func setupSearchControllerDesign() {
        self.searchBar.barTintColor = .mainColorWhite
        self.searchBar.searchTextField.backgroundColor = .mainColorPinK
        self.searchBar.searchTextField.textColor = .mainColorWhite
        self.searchBar.searchTextField.placeholder = ""
        self.searchBar.searchTextField.layer.borderWidth = 1
        self.searchBar.searchTextField.layer.borderColor = UIColor.mainColorWhite.cgColor
        self.searchBar.searchTextField.layer.cornerRadius = 10
        self.hidesNavigationBarDuringPresentation = false
        self.obscuresBackgroundDuringPresentation = false
    }
}


