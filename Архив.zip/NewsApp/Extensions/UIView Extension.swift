////
////  CAGradientLayer Extensions.swift
////  newsApp
////
////  Created by Валерий Мустафин on 07.10.2020.
////  Copyright © 2020 Валерий Мустафин. All rights reserved.
////
import UIKit

extension UIView {
    func createGradient(colorFirst: UIColor, colorLast: UIColor, startPoint: CGPoint, endPoint: CGPoint, useAnimation: Bool) {
        // gradientLayer.colors = [UIColor.mainColorViolet.cgColor, UIColor.mainColorBlack.cgColor]
        // - Standart Color
        let _: CAGradientLayer = {
            let gradientLayer = CAGradientLayer()
            gradientLayer.startPoint = startPoint
            gradientLayer.endPoint = endPoint
            gradientLayer.colors = [colorFirst.cgColor, colorLast.cgColor]
            gradientLayer.locations = [0.3, 1]
            gradientLayer.frame = CGRect(x: 0, y: 0, width: self.bounds.width, height: self.bounds.height)
            if useAnimation {
                let gradientChangeAnimation = CABasicAnimation(keyPath: "colors")
                gradientChangeAnimation.duration = 5.0
                gradientChangeAnimation.toValue = [ UIColor.mainColorViolet.cgColor, UIColor.mainColorBlack.cgColor ]
                gradientChangeAnimation.fillMode = CAMediaTimingFillMode.forwards
                gradientChangeAnimation.isRemovedOnCompletion = false
                gradientLayer.add(gradientChangeAnimation, forKey: "colorChange")
            }
            self.layer.addSublayer(gradientLayer)
            return gradientLayer
        }()
    }
}
