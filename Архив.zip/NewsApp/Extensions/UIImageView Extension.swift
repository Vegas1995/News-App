//
//  UIImageView Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 08.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

extension UIImageView {
    convenience init(with image: UIImage, contentMode: UIView.ContentMode, cornerRadius: CGFloat){
        self.init()
        self.image = #imageLiteral(resourceName: "planet")
        self.contentMode = contentMode
        self.clipsToBounds = true
        self.layer.cornerRadius = cornerRadius
        self.layer.borderWidth = 0.0
        self.layer.masksToBounds = true
        
    }
}
