//
//  DetailArticleViewModel.swift
//  newsApp
//
//  Created by Валерий Мустафин on 09.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import Foundation
//output
protocol DetailArticleViewProtocol: class {
    func updateData()
}
//input
protocol DetailArticleViewModelProtocol: class {
    init(view: DetailArticleViewProtocol, inputModel: Article, inputModelSource: Source)
    //init View
    func getIndent() -> Float
    func getDataTitle() -> String
    func getDataImage() -> URL?
    func getDataTime() -> String
    func getDataContent() -> String
    func getDataUrl() -> String
    func getTitleArticle() -> String
}

class DetailArticleViewModel: DetailArticleViewModelProtocol {
    
    weak var view: DetailArticleViewProtocol?
    var modelSource = Source()
    var model = Article()
    //MARK: Init
    required init(view: DetailArticleViewProtocol, inputModel: Article, inputModelSource: Source) {
        self.view = view
        self.model = inputModel
        self.modelSource = inputModelSource
        updateUI()
    }
    
    func getIndent() -> Float {
        return 2000
    }
    
    func getTitleArticle() -> String {
        return modelSource.name ?? "Article"
    }
    
    func getDataUrl() -> String {
        return model.url?.absoluteString ?? ""
    }
    
    func getDataTitle() -> String {
        return model.title ?? ""
    }
    
    func getDataImage() -> URL? {
        guard let urlValue = model.urlToImage else { return nil }
        return urlValue
    }
    
    func getDataTime() -> String {
        return model.publishedAt?.getCurrentDate() ?? ""
    }
    
    func getDataContent() -> String {
        return model.content ?? ""
    }
    
    //MARK: Private function
    private func updateUI() {
        DispatchQueue.main.async {
            self.view?.updateData()
        }
    }
}
