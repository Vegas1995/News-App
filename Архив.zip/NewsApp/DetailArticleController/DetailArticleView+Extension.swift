//
//  DetailArticleView+Extension.swift
//  newsApp
//
//  Created by Валерий Мустафин on 12.10.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

//MARK: Constraints
extension DetailArticleView {
    func makeConstraints() {
        articleImage.snp.makeConstraints { (makes) in
            makes.topMargin.equalToSuperview().offset(16)
            makes.left.right.equalToSuperview()
            makes.height.equalToSuperview().multipliedBy(0.2)
        }
        titleLabel.snp.makeConstraints { (makes) in
            makes.top.equalTo(articleImage.snp.bottom).offset(12)
            makes.leftMargin.rightMargin.equalToSuperview()
        }
        
        timePublishLabel.snp.makeConstraints { (makes) in
            makes.top.equalTo(titleLabel.snp.bottom).offset(20)
            makes.leftMargin.rightMargin.equalToSuperview()
        }
        
        contentLabel.snp.makeConstraints { (makes) in
            makes.top.equalTo(timePublishLabel.snp.bottom).offset(20)
            makes.leftMargin.rightMargin.equalToSuperview()
        }
        
        urlLabel.snp.makeConstraints { (makes) in
            makes.leftMargin.rightMargin.equalToSuperview()
            makes.bottom.equalToSuperview().offset(-16)
        }
    }
}
