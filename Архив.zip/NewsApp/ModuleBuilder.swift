//
//  ModuleBuilder.swift
//  newsApp
//
//  Created by Валерий Мустафин on 25.09.2020.
//  Copyright © 2020 Валерий Мустафин. All rights reserved.
//

import UIKit

protocol BuilderProtocol {
    static func createModuleNews() -> UIViewController
    static func createModuleArticle(inputModel: Source) -> UIViewController
    static func createModuleDetailArticle(inputModel: Article, inputModelSource: Source) -> UIViewController
}

class ModuleBuilder: BuilderProtocol {
    static func createModuleNews() -> UIViewController {
        let modelSources = [Source]()
        let view = NewsView()
        let networkSevice = NetworkService()
        let viewModel = NewsViewModel(view: view, networkService: networkSevice, modelSources: modelSources)
        view.viewModel = viewModel
        return view
    }
    
    static func createModuleArticle(inputModel: Source) -> UIViewController {
        let model = [Article]()
        let view = ArticlesView()
        let networkSevice = NetworkService()
        let viewModel = ArticlesViewModel(view: view, networkService: networkSevice, model: model, inputModel: inputModel)
        view.viewModel = viewModel
        return view
    }
    
    static func createModuleDetailArticle(inputModel: Article, inputModelSource: Source) -> UIViewController {
        let view = DetailArticleView()
        let viewModel = DetailArticleViewModel(view: view, inputModel: inputModel, inputModelSource: inputModelSource)
        view.viewModel = viewModel
        return view
    }
    
}
